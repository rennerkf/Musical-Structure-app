package com.example.musicalstructureapp;

public class Info {
    public static String BOOK_TITLE = "book_title";
    public static String BOOK_AUTHOR = "book_author";
    public static String BOOK_COVER = "book_cover";
    public static String NOW_PLAYING = "now_playing";
}
