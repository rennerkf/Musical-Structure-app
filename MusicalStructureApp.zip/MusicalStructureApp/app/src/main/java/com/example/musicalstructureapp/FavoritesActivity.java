package com.example.musicalstructureapp;

public class FavoritesActivity {
}
