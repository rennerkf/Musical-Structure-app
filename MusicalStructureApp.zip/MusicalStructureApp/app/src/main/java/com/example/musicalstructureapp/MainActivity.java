package com.example.musicalstructureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        // Set the content of the activity to use the activity_main.xml layout file
        setContentView(R.layout.activity_main);

        // Find the View that shows the audiobooks category
        TextView audiobooks = (TextView) findViewById(R.id.audiobooks);

        // Set a click listener on that View
        audiobooks.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the audiobooks category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link AudiobooksActivity}
                Intent audiobooksIntent = new Intent(MainActivity.this, AudiobooksActivity.class);

                // Start the new activity
                startActivity(audiobooksIntent);

            }
        });



        // Find the View that shows the colors category
        TextView favorites = (TextView) findViewById(R.id.favorites);

        // Set a click listener on that View
        favorites.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the favorites category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link FavoritesActivity}
                Intent favoritesIntent = new Intent(MainActivity.this, FavoritesActivity.class);

                // Start the new activity
                startActivity(favoritesIntent);
            }
        });





    }




}